title: 事件分发机制如何走到dispatchEventTouch方法中去的
date: '2019-09-12 17:37:41'
updated: '2019-09-12 17:38:23'
tags: [Note, 笔记, android]
permalink: /articles/2019/09/12/1568281061698.html
---
![](https://img.hacpai.com/bing/20180626.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

待续...
