title: Java集合系列之ArrayList源码分析
date: '2019-10-24 17:55:17'
updated: '2019-11-01 16:47:06'
tags: [Java集合]
permalink: /articles/2019/10/24/1571910917492.html
---
### 数组(Array)
数组指的就是一组相关类型的变量集合，并且这些变量可以按照统一的方式进行操作，数组数据引用数据类型，在堆中进行内存分配，在内存中是连续存在，大小固定的。
### ArrayList
ArrayList可以算是数组的加强版，其继承AbstractList接口，实现了List，RandomAccess，Cloneable接口，可序列化。在存储方面 数组可以包含基本类型和对象类型，比如：int[],Object[]，ArrayList只能包含对象类型；在空间方面，数组的空间大小是固定的，空间不够时不能再次申请，所以需要事前确定合适的空间大小。ArrayList的空间是动态增长的，如果空间不足，它会创建一个1.5倍大的新数组，然后把所有元素复制到新数组，而且每次添加新的元素时会检测内部数组的空间是否足够。
### 源码解析
#### 变量

```
    //默认初始容量	
    private static final int DEFAULT_CAPACITY = 10;
    //空数组	
    private static final Object[] EMPTY_ELEMENTDATA = {};

    //空数组与EMPTY_ELEMENTDATA 区别在于添加第一个元素时，扩充多少
    private static final Object[] DEFAULTCAPACITY_EMPTY_ELEMENTDATA = {};

    //实例数组对象
    transient Object[] elementData; // non-private to simplify nested class access

    //数组大小
    private int size;
```
#### 构造函数
 ArrayList的构造方法有三种：
```
//自定义初始容量
public ArrayList(int initialCapacity) {
        if (initialCapacity > 0) {
	    //初始化容量大小	
            this.elementData = new Object[initialCapacity];
        } else if (initialCapacity == 0) {
            this.elementData = EMPTY_ELEMENTDATA;
        } else {
	    //容量初始值不能 < 0 小于零会抛出异常
            throw new IllegalArgumentException("Illegal Capacity: "+
                                               initialCapacity);
        }
    }

//常用无参构造函数，默认数组大小为 10
public ArrayList() {
        this.elementData = DEFAULTCAPACITY_EMPTY_ELEMENTDATA;
    }

//创建一个包含collection的ArrayList
public ArrayList(Collection<? extends E> c) {
        elementData = c.toArray();
        if ((size = elementData.length) != 0) {
            // c.toArray might (incorrectly) not return Object[] (see 6260652)
            if (elementData.getClass() != Object[].class)
		//构造大小为size的Object[]数组赋值给elementData
                elementData = Arrays.copyOf(elementData, size, Object[].class);
        } else {
            // 替换空数组
            this.elementData = EMPTY_ELEMENTDATA;
        }
    }

```
#### 常用函数(方法)
##### add函数
ArrayList调用add()方法添加函数，源码为
```
//在数组尾部添加元素	
public boolean add(E e) {
	//长度+1，也就是修改次数+1 确保内部容量
        ensureCapacityInternal(size + 1);  // Increments modCount!!
	//数组下标+1 并赋值
        elementData[size++] = e;
        return true;
    }

private void ensureCapacityInternal(int minCapacity) {
	//若数组元素为空，取最小容量，与默认容量的最大值做为最小容量
        if (elementData == DEFAULTCAPACITY_EMPTY_ELEMENTDATA) {
            minCapacity = Math.max(DEFAULT_CAPACITY, minCapacity);
        }
	//明确ArrayList的最小容量
        ensureExplicitCapacity(minCapacity);
    }
//用于内部优化确保空间资源不被浪费
private void ensureExplicitCapacity(int minCapacity) {
	//修改统计数+1，主要用来实现fail-fast机制
        modCount++;

        // 防止溢出，保证最小容量 > 数组缓冲区当前长度
        if (minCapacity - elementData.length > 0)
	    //增加容量
            grow(minCapacity);
    }

```
```
 //增加容量以确保它至少可以容纳最小容量参数指定的元素数量。
 private void grow(int minCapacity) {
        // 元素长度为旧容量大小
        int oldCapacity = elementData.length;
	// 新容量= 旧容量 + 旧容量右移一位（旧容量/2）
        int newCapacity = oldCapacity + (oldCapacity >> 1);
	//判断新容量与最小容量大小 
        if (newCapacity - minCapacity < 0)
	    //最小容量>新容量 ，则新容量为最小容量
            newCapacity = minCapacity;
	//若新容量 > 最大容量 ，对新容量重新计算
        if (newCapacity - MAX_ARRAY_SIZE > 0)
	    //重新计算新容量
            newCapacity = hugeCapacity(minCapacity);
        // 扩容并赋值数组元素
        elementData = Arrays.copyOf(elementData, newCapacity);
    }

private static int hugeCapacity(int minCapacity) {
	//若最小容量 < 0 则抛出异常
        if (minCapacity < 0) // overflow
            throw new OutOfMemoryError();
	//最小容量大于 最大数组长度，则返回int最大值作为容量大小
        return (minCapacity > MAX_ARRAY_SIZE) ?
            Integer.MAX_VALUE :
            MAX_ARRAY_SIZE;
    }

```
查看复制数组方法
```
Arrays.copyOf(elementData, newCapacity)

//Arrays.java类中的方法
public static <T> T[] copyOf(T[] original, int newLength) {
        return (T[]) copyOf(original, newLength, original.getClass());
    
//复制指定的数组，截断或使用null填充（如果需要），以便副本具有指定的长度。
// 对于在原始数组和副本中均有效的所有索引，两个数组将包含相同的值
public static <T,U> T[] copyOf(U[] original, int newLength, Class<? extends T[]> newType) {
        @SuppressWarnings("unchecked")
        T[] copy = ((Object)newType == (Object)Object[].class)
            ? (T[]) new Object[newLength]
            : (T[]) Array.newInstance(newType.getComponentType(), newLength);
	//从指定的源数组开始复制数组，从指定的位置开始到目标数组的指定位置
        System.arraycopy(original, 0, copy, 0,
                         Math.min(original.length, newLength));
        return copy;
    }

//内部调用System.arraycopy方法
@FastNative
public static native void arraycopy(Object src,  int  srcPos,
                                        Object dest, int destPos,
                                        int length);
```
```
在对应下标出添加数据元素
public void add(int index, E element) {
	//超出数据长度或 小于0 ，则抛出数组越界异常
        if (index > size || index < 0) 
            throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
	///增加容量以确保它至少可以容纳最小容量参数指定的元素数量，修改次数+1
        ensureCapacityInternal(size + 1);  // Increments modCount!!
	//数组拷贝赋值
        System.arraycopy(elementData, index, elementData, index + 1,
                         size - index);
        elementData[index] = element;
        size++;
    }
//添加数组集合
public boolean addAll(Collection<? extends E> c) {
	//转化数据
        Object[] a = c.toArray();
        int numNew = a.length;
	//修改次数+1
        ensureCapacityInternal(size + numNew);  // Increments modCount
	//数组拷贝赋值
        System.arraycopy(a, 0, elementData, size, numNew);
        size += numNew;
        return numNew != 0;
    }

```
通过分析add方法可以发现ArrayList内部是调用System.arraycopy方法复制数组。
#####  remove函数

