title: Java集合系列之ArrayList源码分析
date: '2019-10-24 17:55:17'
updated: '2019-10-24 20:01:01'
tags: [待分类]
permalink: /articles/2019/10/24/1571910917492.html
---
### 数组(Array)
数组指的就是一组相关类型的变量集合，并且这些变量可以按照统一的方式进行操作，数组数据引用数据类型，在堆中进行内存分配，在内存中是连续存在，大小固定的。
### ArrayList
ArrayList可以算是数组的加强版，其继承AbstractList接口，实现了List，RandomAccess，Cloneable接口，可序列化。在存储方面 数组可以包含基本类型和对象类型，比如：int[],Object[]，ArrayList只能包含对象类型；在空间方面，数组的空间大小是固定的，空间不够时不能再次申请，所以需要事前确定合适的空间大小。ArrayList的空间是动态增长的，如果空间不足，它会创建一个1.5倍大的新数组，然后把所有元素复制到新数组，而且每次添加新的元素时会检测内部数组的空间是否足够。
### 源码解析
#### 变量

```
    //默认初始容量	
    private static final int DEFAULT_CAPACITY = 10;
    //空数组	
    private static final Object[] EMPTY_ELEMENTDATA = {};

    //空数组与EMPTY_ELEMENTDATA 区别在于添加第一个元素时，扩充多少
    private static final Object[] DEFAULTCAPACITY_EMPTY_ELEMENTDATA = {};

    //实例数组对象
    transient Object[] elementData; // non-private to simplify nested class access

    //数组大小
    private int size;
```

