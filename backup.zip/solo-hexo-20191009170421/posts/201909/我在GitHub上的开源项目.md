title: 我在 GitHub 上的开源项目
date: '2019-09-02 18:44:34'
updated: '2019-09-02 18:44:34'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [MVPPlugins](https://github.com/Sotardust/MVPPlugins) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Sotardust/MVPPlugins/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Sotardust/MVPPlugins/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Sotardust/MVPPlugins/network/members "分叉数")</span>

根据Google官方给出的 MVP模式生成对应文件



---

### 2. [Algorithm_Java](https://github.com/Sotardust/Algorithm_Java) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Sotardust/Algorithm_Java/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Sotardust/Algorithm_Java/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Sotardust/Algorithm_Java/network/members "分叉数")</span>





---

### 3. [Notes](https://github.com/Sotardust/Notes) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Sotardust/Notes/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Sotardust/Notes/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Sotardust/Notes/network/members "分叉数")</span>

各语言 知识点 学习笔记



---

### 4. [solo-blog](https://github.com/Sotardust/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Sotardust/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Sotardust/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Sotardust/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.sotardust.cn`](https://www.sotardust.cn "项目主页")</span>

Sotardust 的个人博客 - 记录精彩的程序人生



---

### 5. [NovelServer](https://github.com/Sotardust/NovelServer) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Sotardust/NovelServer/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Sotardust/NovelServer/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Sotardust/NovelServer/network/members "分叉数")</span>

Novel的服务端



---

### 6. [Message](https://github.com/Sotardust/Message) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Sotardust/Message/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Sotardust/Message/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Sotardust/Message/network/members "分叉数")</span>

若有未接来电，把信息通知给微信PC端，给出通知提醒



---

### 7. [Utils](https://github.com/Sotardust/Utils) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Sotardust/Utils/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Sotardust/Utils/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Sotardust/Utils/network/members "分叉数")</span>





---

### 8. [Algorithm](https://github.com/Sotardust/Algorithm) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Sotardust/Algorithm/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Sotardust/Algorithm/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Sotardust/Algorithm/network/members "分叉数")</span>

算法、设计模式、代码重构学习



---

### 9. [ChatDemo](https://github.com/Sotardust/ChatDemo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Sotardust/ChatDemo/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Sotardust/ChatDemo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Sotardust/ChatDemo/network/members "分叉数")</span>





---

### 10. [Zero](https://github.com/Sotardust/Zero) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Sotardust/Zero/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Sotardust/Zero/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Sotardust/Zero/network/members "分叉数")</span>

使用 MVP+Retrofit+Rxjava + dagger2 +Material Design 构架的练手项目

