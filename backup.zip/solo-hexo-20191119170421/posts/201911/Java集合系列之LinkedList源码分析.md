title: Java集合系列之LinkedList源码分析
date: '2019-11-08 18:00:16'
updated: '2019-11-19 16:46:43'
tags: [待分类]
permalink: /articles/2019/11/08/1573207216254.html
---
![](https://img.hacpai.com/bing/20190212.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 前言
LinkedList是基于双向链表实现的，除了可以当链表来操作，它还可以当做栈，队列以及双端队列来使用，且是非线程安全。
```
public class LinkedList<E>
    extends AbstractSequentialList<E>
    implements List<E>, Deque<E>, Cloneable, java.io.Serializable
```
LinkedList继承了AbstractSequentialList类实现了List集合，Deque队列，Cloneable支持克隆，Serializable支持序列化

### 类的属性
```
//集合长度
transient int size = 0;
//链表头节点
transient Node<E> first;
//链表尾节点
transient Node<E> last;
```
### 内部核心类 Node
```
	
    private static class Node<E> {
        E item;//节点对应元素
        Node<E> next; //当前节点的后一个节点的引用
        Node<E> prev;//当前节点的前一个节点的引用

        Node(Node<E> prev, E element, Node<E> next) {
            this.item = element;
            this.next = next;
            this.prev = prev;
        }
    }
```
### 构造函数
LinkedList 共两个构造函数
```
   //构造空链表
   public LinkedList() {
    }

   //构造一个包含指定集合的元素的里List
   public LinkedList(Collection<? extends E> c) {
        this();
        addAll(c);
    }

```
### LinkedList操作函数

#### add(E e)
```
   public boolean add(E e) {
	//向链表尾部添加元素
        linkLast(e);
        return true;
    }

   void linkLast(E e) {
        final Node<E> l = last;
        final Node<E> newNode = new Node<>(l, e, null);
        last = newNode;
        if (l == null)
            first = newNode;
        else
            l.next = newNode;
        size++;
        modCount++;
    }

```


> 相关文章阅读
[Java集合系列之HashMap源码分析](https://www.sotardust.cn/articles/2019/09/16/1568600871079.html)
[Java集合系列之ArrayList源码分析](https://www.sotardust.cn/articles/2019/10/24/1571910917492.html)

#### Android 源码解析系列分析

> [自定义View绘制过程源码分析](https://www.sotardust.cn/articles/2019/09/02/1567419491078.html)
[ViewGroup绘制过程源码分析](https://www.sotardust.cn/articles/2019/09/02/1567419461969.html)
[ThreadLocal 源码分析](https://www.sotardust.cn/articles/2019/09/02/1567419434677.html)
[Handler消息机制源码分析](https://www.sotardust.cn/articles/2019/09/02/1567419402891.html)
[Android 事件分发机制源码分析](https://www.sotardust.cn/articles/2019/09/02/1567419369662.html)
[Activity启动过程源码分析](https://www.sotardust.cn/articles/2019/09/02/1567419276652.html)
[Activity中View创建到添加在Window窗口上到显示的过程源码分析](https://www.sotardust.cn/articles/2019/09/02/1567419224191.html)

